package edu.jsp.ak.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.jsp.ak.Dao.identityDao;
import edu.jsp.ak.Dto.identity;

@Service
public class identityService {
	@Autowired
	public identityDao dao;
	
	public identity saveIdentity(identity i) {
		return dao.saveIdentity(i);
	}
	public identity fetchById(int id) {
		return dao.fetchById(id);
	}
	public List<identity> fetchAll(){
		return dao.fetchAll();
	}
	public String deleteById(int id) {
	    identity i=dao.fetchById(id);
	    if(i!=null) {
	    	dao.deleteById(id);
	    	return id+" deleted";
	    }
	    return null;
	}
	public identity updateIdentity(int id,identity i) {
		identity i1=dao.fetchById(id);
		if(i1!=null) {
			i.setId(id);
			return dao.updateIdentity(i);
		}
		return null;
	}
}
