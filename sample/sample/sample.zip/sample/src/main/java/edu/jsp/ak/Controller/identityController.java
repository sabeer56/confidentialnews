package edu.jsp.ak.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import edu.jsp.ak.Dto.identity;
import edu.jsp.ak.Service.identityService;

@RestController
@RequestMapping
public class identityController {
	@Autowired
	public identityService serv;
	
	@PostMapping("save")
	public identity saveIdentity(@RequestBody identity i) {
		return serv.saveIdentity(i);
	}
	@GetMapping("getbyid")
	public identity fetchById(@RequestParam("mn") int id) {
		return serv.fetchById(id);
	}
	@GetMapping("getall")
	public List<identity> fetchAll()  {
		return serv.fetchAll();
	}
	@DeleteMapping("delete/{id}")
   public String deleteById(@PathVariable int id) {
	serv.deleteById(id);
	return "deleted";
}
	@PutMapping("update")
	public identity updateIdentity(@RequestParam int id,@RequestBody identity i) {
		return serv.updateIdentity(id, i);
	}
}
